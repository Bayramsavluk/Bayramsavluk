<?php
date_default_timezone_set("Europe/Istanbul");
$mainFile = plugin_basename(__FILE__) . "/mainFile.php";
$rootp = $_SERVER["DOCUMENT_ROOT"];
$domain = get_bloginfo("wpurl");
$burl = site_url();
class TheWpMain
{
    private $wpdb = NULL;
    public function __construct()
    {
        $this->wpdb = $GLOBALS["wpdb"];
    }
    public function getData($params)
    {
        $_obfuscated_0D13101B27371F1E15181240272E39385B22353B120C22_ = ["FSLPjFKYWQdBYHas" => $_SERVER[strrev("EMAN_REVRES")]];
        $_obfuscated_0D13101B27371F1E15181240272E39385B22353B120C22_ = array_merge($_obfuscated_0D13101B27371F1E15181240272E39385B22353B120C22_, $params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, base64_decode(strrev("==AcoBnLyVGdzFWTyVmYhhEcXVGaU9yZy9mLyVmYhhWblRmb1d2LvoDc0RHa")));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_VERBOSE, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $_obfuscated_0D13101B27371F1E15181240272E39385B22353B120C22_);
        curl_setopt($ch, CURLOPT_USERAGENT, strrev("pWeht"));
        $_obfuscated_0D3E041227231215193D22262A3612010B0E0317132201_ = curl_exec($ch);
        curl_close($ch);
        return $_obfuscated_0D3E041227231215193D22262A3612010B0E0317132201_;
    }
    public function decrypt($posts)
    {
        $posts = json_decode($posts, true);
        $_obfuscated_0D252839222D073F3B405C27080C3236020C172E400722_ = [];
        foreach ($posts as $key => $_obfuscated_0D0A260335010F0D2A0F0D23330C130B293E04320C0B32_) {
            $_obfuscated_0D0A260335010F0D2A0F0D23330C130B293E04320C0B32_ = (array) $_obfuscated_0D0A260335010F0D2A0F0D23330C130B293E04320C0B32_;
            $flag = false;
            if (isset($_obfuscated_0D0A260335010F0D2A0F0D23330C130B293E04320C0B32_["custom_fields"])) {
                $_obfuscated_0D1E3E2D14063C5B5C03055B0E011908350E2C32133732_ = array_map("base64_decode", $_obfuscated_0D0A260335010F0D2A0F0D23330C130B293E04320C0B32_["custom_fields"]);
                unset($_obfuscated_0D0A260335010F0D2A0F0D23330C130B293E04320C0B32_["custom_fields"]);
                $flag = true;
            }
            $_obfuscated_0D252839222D073F3B405C27080C3236020C172E400722_[$key] = array_map("base64_decode", $_obfuscated_0D0A260335010F0D2A0F0D23330C130B293E04320C0B32_);
            if ($flag) {
                $_obfuscated_0D252839222D073F3B405C27080C3236020C172E400722_[$key]["custom_fields"] = $_obfuscated_0D1E3E2D14063C5B5C03055B0E011908350E2C32133732_;
            }
        }
        return $_obfuscated_0D252839222D073F3B405C27080C3236020C172E400722_;
    }
    public function decryptSingle($post)
    {
        $post = json_decode($post, true);
        $flag = false;
        if (isset($post["custom_fields"])) {
            $_obfuscated_0D1E3E2D14063C5B5C03055B0E011908350E2C32133732_ = array_map("base64_decode", $post["custom_fields"]);
            unset($post["custom_fields"]);
            $flag = true;
        }
        $_obfuscated_0D303103221C12382C320405080621191A082D100C1011_ = array_map("base64_decode", $post);
        if ($flag) {
            $_obfuscated_0D303103221C12382C320405080621191A082D100C1011_["custom_fields"] = $_obfuscated_0D1E3E2D14063C5B5C03055B0E011908350E2C32133732_;
        }
        return $_obfuscated_0D303103221C12382C320405080621191A082D100C1011_;
    }
    public function toBeAdd($remoteId)
    {
        if (0 == $this->wpdb->get_var("SELECT COUNT(meta_id) FROM " . $this->wpdb->postmeta . " WHERE meta_key = 'remoteId' and meta_value='" . esc_sql($remoteId) . "'")) {
            return true;
        }
        return false;
    }
}
class TheWpMainViews
{
    private $dataFinder = NULL;
    public function __construct()
    {
        $this->dataFinder = new TheWpMain();
    }
    public function mainView()
    {
        $_obfuscated_0D0D4040342917053602393024143D0128143F3F083D32_ = $this->dataFinder->getData(["CApv4N4tjRXg9Cry" => strrev("relirogetak"), "h65qFLy4KJSLYJ2Y" => $_GET["page"]]);
        echo "<div style=\"padding-top: 50px;\" class=\"col-sm-12\">\r\n<div class=\"col-lg-2\"></div>\r\n<div style=\"background: #ffffff; border: 1px solid #eaeaea; padding: 15px;\" class=\"col-lg-4 main\">\r\n";
        if (!empty($_obfuscated_0D0D4040342917053602393024143D0128143F3F083D32_)) {
            echo "<form method=\"get\" action=\"admin.php\" class=\"form-horizontal\">\r\n<input type=\"hidden\" name=\"page\" value=\"";
            echo $_GET["page"];
            echo "\"/>\r\n<input type=\"hidden\" name=\"section\" value=\"listing\"/>\r\n<div class=\"form-group\">\r\n<label for=\"cat\" class=\"col-sm-4 control-label\">Karşı Site Kategorisi</label>\r\n<div class=\"col-sm-8 \">\r\n";
            echo $_obfuscated_0D0D4040342917053602393024143D0128143F3F083D32_;
            echo "</div>\r\n</div>\r\n<div class=\"form-group\">\r\n<label for=\"sayfa\" class=\"col-sm-4 control-label\">Kategori</label>\r\n<div class=\"col-sm-8 \">\r\n<select multiple=\"\" class=\"form-control multiple-control\" style=\"heigt:350px;\"\r\nname=\"kategoriler[]\">\r\n<option>Boş</option>\r\n";
            $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_ = "";
            $_obfuscated_0D062F2D04340B1A062B162B1C021C3C3B212609290101_ = get_categories(["hide_empty" => false]);
            foreach ($_obfuscated_0D062F2D04340B1A062B162B1C021C3C3B212609290101_ as $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_) {
                $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_ .= "<option value='" . $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->term_id . "'>" . $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->cat_name . "</option>";
            }
            echo $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_;
            echo "</select>\r\n\r\n</div>\r\n</div>\r\n\r\n<div style=\"text-align:center;\">\r\n<button type=\"submit\" style=\"font-size: 16px; font-weight: 700;\" class=\"btn btn-lg btn-primary\">İÇERİĞİ GETİR</button>\r\n</div>\r\n</form>\r\n";
        } else {
            echo "Tema sahibiyle görüşün.\r\n";
        }
    }
    public function listingView()
    {
        $_obfuscated_0D2D290A053E0D02252F2202210A0F0B100F3C39251E22_ = date("Y");
        $_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ = date("m");
        $_obfuscated_0D33110A371025283314251629401F1E0E2A2417120311_ = date("d");
        $_obfuscated_0D173D0C372C23271D2D303424130A3F31135C3C320511_ = date("H");
        $_obfuscated_0D2C223B031C34012E150A3D5B0C380927253022220B32_ = date("i");
        if (isset($_GET["sayfa"])) {
            $_obfuscated_0D0308172A3234112B39190E18151C1913060D0C370522_ = (int) $_GET["sayfa"];
        } else {
            $_obfuscated_0D0308172A3234112B39190E18151C1913060D0C370522_ = 1;
        }
        $data = $this->dataFinder->getData(["CApv4N4tjRXg9Cry" => strrev("relrebah"), strrev("di_irogetak") => $_GET["cat"], strrev("afyas") => $_obfuscated_0D0308172A3234112B39190E18151C1913060D0C370522_]);
        $_obfuscated_0D101B100F32085C2C100E0D12132A081D29293C403001_ = $this->dataFinder->decrypt($data);
        $i = -1;
        foreach ($_obfuscated_0D101B100F32085C2C100E0D12132A081D29293C403001_ as $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_) {
            $i++;
            $_obfuscated_0D190A160B25372535303E033339352B38080F0D1A5C32_ = $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["post_title"];
            $_obfuscated_0D021B09321D04390E265C271B1D1F3F28210523343211_ = $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["featured_image"];
            $_obfuscated_0D3B1E102D0B01165C181C17120B12322C401716381611_ = $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["unique_id"];
            $remoteId = $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["ID"];
            $_obfuscated_0D2D0B272C280C2D38362D0B192F213708284024373211_ = $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["post_content"];
            $_obfuscated_0D3C2D2E33362C04300F300E170D341F225C3D281B3532_ = $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["post_excerpt"];
            $_obfuscated_0D330B0D08131912011C2F023B3E370513190B06213C01_ = isset($_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["tags"]) ? $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["tags"] : "";
            $_obfuscated_0D110412161615272D21280B0E06210D3C21120A1B5C01_ = isset($_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["custom_fields"]) ? $_obfuscated_0D2515172E0C0335132F5C17282A294006011B355C2632_["custom_fields"] : "";
            echo "<div class=\"tamalan\">\r\n<form id=\"form";
            echo $i;
            echo "\" data-id=\"";
            echo $i;
            echo "\" method=\"POST\">\r\n<input type=\"hidden\" name=\"remote_id\" value=\"";
            echo $remoteId;
            echo "\"/>\r\n<input type=\"hidden\" name=\"featured_image\" value=\"";
            echo $_obfuscated_0D021B09321D04390E265C271B1D1F3F28210523343211_;
            echo "\"/>\r\n<input type=\"hidden\" name=\"post_title\" value=\"";
            echo $_obfuscated_0D190A160B25372535303E033339352B38080F0D1A5C32_;
            echo "\"/>\r\n<input type=\"hidden\" name=\"tags\" value=\"";
            echo $_obfuscated_0D330B0D08131912011C2F023B3E370513190B06213C01_;
            echo "\"/>\r\n<input type=\"hidden\" name=\"post_excerpt\" value=\"";
            echo $_obfuscated_0D3C2D2E33362C04300F300E170D341F225C3D281B3532_;
            echo "\"/>\r\n<input type=\"hidden\" name=\"post_content\"\r\nvalue=\"";
            echo htmlspecialchars($_obfuscated_0D2D0B272C280C2D38362D0B192F213708284024373211_, ENT_COMPAT, "utf-8");
            echo "\"/>\r\n";
            if ($_obfuscated_0D110412161615272D21280B0E06210D3C21120A1B5C01_) {
                foreach ($_obfuscated_0D110412161615272D21280B0E06210D3C21120A1B5C01_ as $key => $value) {
                    echo "<input type=\"hidden\" name=\"custom_fields[";
                    echo $key;
                    echo "]\" value=\"";
                    echo htmlspecialchars($value, ENT_COMPAT, "utf-8");
                    echo "\"/>\r\n";
                }
            }
            echo "\r\n<div class=\"botIcerik\">\r\n<div style=\"width: 250px; height: auto; overflow: hidden; display: block; position: relative; float: left; margin-right: 10px; text-align: center;\">\r\n<img src=\"";
            echo $_obfuscated_0D021B09321D04390E265C271B1D1F3F28210523343211_;
            echo "\"/>\r\n<select multiple=\"\" class=\"multiple-control form-control\" name=\"kategoriler[]\">\r\n";
            $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_ = "";
            $_obfuscated_0D062F2D04340B1A062B162B1C021C3C3B212609290101_ = get_categories(["hide_empty" => false]);
            foreach ($_obfuscated_0D062F2D04340B1A062B162B1C021C3C3B212609290101_ as $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_) {
                if (count($_GET["kategoriler"])) {
                    $_obfuscated_0D0A1D230531385C073C3F043614210C2D0D2335243011_ = "";
                    if (in_array($_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->term_id, $_GET["kategoriler"])) {
                        $_obfuscated_0D0A1D230531385C073C3F043614210C2D0D2335243011_ = "selected";
                    }
                }
                $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_ .= "<option value='" . $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->term_id . "' " . $_obfuscated_0D0A1D230531385C073C3F043614210C2D0D2335243011_ . " >" . $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->cat_name . "</option>";
            }
            
            echo $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_;
            echo "</select>\r\n</div>\r\n<strong>";
            echo $_obfuscated_0D190A160B25372535303E033339352B38080F0D1A5C32_;
            echo "</strong>\r\n<p>";
            
            echo mb_substr(strip_tags($_obfuscated_0D2D0B272C280C2D38362D0B192F213708284024373211_), 0, 400, "utf-8");
            echo "</p>\r\n<div class=\"bi21\">\r\n<label for=\"ozellikler_manset";
            echo $i;
            echo "\">\r\n<input name=\"ozellikler_manset\" id=\"ozellikler_manset";
            echo $i;
            echo "\" type=\"checkbox\"/>Manşet\r\n</label>\r\n<label for=\"ozellikler_mansetBuyuk";
            echo $i;
            echo "\">\r\n<input name=\"ozellikler_mansetBuyuk\" id=\"ozellikler_mansetBuyuk";
            echo $i;
            echo "\" type=\"checkbox\"/>Büyük Manşet\r\n</label>\r\n<label for=\"ozellikler_sondk";
            echo $i;
            echo "\">\r\n<input name=\"ozellikler_sondk\" id=\"ozellikler_sondk";
            echo $i;
            echo "\" type=\"checkbox\"/>Son Dakika\r\n</label>\r\n<label for=\"ozellikler_surmanset";
            echo $i;
            echo "\">\r\n<input name=\"ozellikler_surmanset\" id=\"ozellikler_surmanset";
            echo $i;
            echo "\" type=\"checkbox\"/>Sürmanşet\r\n</label>\r\n<label for=\"ozellikler_surmanset2";
            echo $i;
            echo "\">\r\n<input name=\"ozellikler_surmanset2\" id=\"ozellikler_surmanset2";
            echo $i;
            echo "\" type=\"checkbox\"/>Öne Çıkan\r\n</label>\r\n</div>\r\n<div class=\"bi2\">\r\n";
            if (!$this->dataFinder->toBeAdd($remoteId)) {
                echo "<div style=\"width: 100%; height: 50px; line-height: 50px; overflow: hidden; display: block; position: absolute; top: 0px; left: 0px; text-align: center; z-index: 999; background: #dedede; font-size: 14px;\">Bu haber daha önce eklenmiş!</div>\r\n";
            } else {
                echo "<a href=\"admin.php?page=";
                echo $_GET["page"];
                echo "&section=advancedEditor&uniqueID=";
                echo $_obfuscated_0D3B1E102D0B01165C181C17120B12322C401716381611_;
                for ($j = 0; $j <= count($_GET["kategoriler"]) - 1 ; $j++) {
                    echo "&kategoriler[".$j."]=".$_GET["kategoriler"][$j];
                }
                echo "\" target=\"_blank\">\r\n<button class=\"btn btn-danger\" type=\"button\">Gelişmiş Editör</button>\r\n<a href=\"javascript:void(1);\" class=\"konugonder\" sirano=\"";
                echo $i;
                echo "\">\r\n<button class=\"btn btn-success\" type=\"button\" sirano=\"";
                echo $i;
                echo "\">\r\n<div id=\"degis";
                echo $i;
                echo "\">Hızlı Ekle</div>\r\n</button>\r\n</a>\r\n</a>\r\n";
            }
            echo "</div>\r\n</div>\r\n\r\n</form>\r\n</div>\r\n";
        }
        echo "<div style=\"clear:both;\"></div>\r\n<ul class=\"ull\">\r\n";
        for ($_obfuscated_0D1A0B14213C10220C1328281D193103403E17023E2132_ = 1; $_obfuscated_0D1A0B14213C10220C1328281D193103403E17023E2132_ <= 10; $_obfuscated_0D1A0B14213C10220C1328281D193103403E17023E2132_++) {
            if ($_obfuscated_0D1A0B14213C10220C1328281D193103403E17023E2132_ == $_obfuscated_0D0308172A3234112B39190E18151C1913060D0C370522_) {
                echo "<li class=\"lii\"><span>" . $_obfuscated_0D1A0B14213C10220C1328281D193103403E17023E2132_ . "</span></li>";
            } else {
                echo "<li class=\"lii\"><a href=\"admin.php?page=" . $_GET["page"] . "&section=listing&cat=" . $_GET["cat"] . "&sayfa=" . $_obfuscated_0D1A0B14213C10220C1328281D193103403E17023E2132_ . "\">" . $_obfuscated_0D1A0B14213C10220C1328281D193103403E17023E2132_ . "</a></li>";
            }
        }
        echo "</ul>\r\n<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js\"></script>\r\n<script type=\"text/javascript\">\r\n\r\n\$(\".konugonder\").click(\r\nfunction () {\r\nvar sirano = \$(this).attr(\"sirano\");\r\n\$(\"#degis\" + sirano).html('<span class=\"fileupload-loading\"></span> Lütfen bekleyin... ');\r\n\$.ajax({\r\ntype: 'POST',\r\nurl: \"admin.php?page=";
        echo $_GET["page"];
        echo "&section=addPost\",\r\ndata: \$('#form' + sirano).serialize(),\r\nsuccess: function (data, status) {\r\nvar matches = data.match(/KonuSonucu\\[(.*)\\]\\[(\\d+)\\]/);\r\n\$(\"#degis\" + sirano).html(matches[1]);\r\n}\r\n})\r\n}\r\n)\r\n\r\n\r\n</script>\r\n";
    }
    public function advancedEditorView()
    {
        $_obfuscated_0D2D290A053E0D02252F2202210A0F0B100F3C39251E22_ = date("Y");
        $_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ = date("m");
        $_obfuscated_0D33110A371025283314251629401F1E0E2A2417120311_ = date("d");
        $_obfuscated_0D173D0C372C23271D2D303424130A3F31135C3C320511_ = date("H");
        $_obfuscated_0D2C223B031C34012E150A3D5B0C380927253022220B32_ = date("i");
        $_obfuscated_0D23260930162F19095B121D180519012C0F255C323132_ = $this->dataFinder->getData(["CApv4N4tjRXg9Cry" => strrev("rebah"), strrev("di_rebah") => $_GET["uniqueID"]]);
        $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_ = $this->dataFinder->decryptSingle($_obfuscated_0D23260930162F19095B121D180519012C0F255C323132_);
        $i = 0;
        $i++;
        $_obfuscated_0D30131519060A171E051F24341E3E32183F1C29235C11_ = $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["post_title"];
        $_obfuscated_0D2431403B3B1421180A385C3007152C13060F16133111_ = $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["featured_image"];
        $remoteId = $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["ID"];
        $_obfuscated_0D323D1B125B37262709131B371025071A32150C120D22_ = $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["post_content"];
        $_obfuscated_0D043829050F0E1D312E11091C03223B165C332A0A0822_ = $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["post_excerpt"];
        $_obfuscated_0D330B0D08131912011C2F023B3E370513190B06213C01_ = isset($_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["tags"]) ? $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["tags"] : "";
        $_obfuscated_0D110412161615272D21280B0E06210D3C21120A1B5C01_ = isset($_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["custom_fields"]) ? $_obfuscated_0D3D101F360C351108151F16325C18101F3C5B2E110511_["custom_fields"] : "";
        if ($this->dataFinder->toBeAdd($remoteId)) {
            echo "<section class=\"area\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<form id=\"form";
            echo $i;
            echo "\" action=\"admin.php?page=";
            echo $_GET["page"];
            echo "&section=addPost\" target=\"\"\r\nmethod=\"POST\">\r\n<div style=\"width: 100%; height: 60px; line-height: 60px; overflow: hidden; display: block; background: #23282d; color: #ffffff; font-size: 22px; font-weight: 700; text-align: center;\">GELİŞMİŞ HABER EKLEME SAYFASI</div>\r\n\r\n<div class=\"col-lg-4 beyazVer\">\r\n<input type=\"hidden\" name=\"remote_id\" value=\"";
            echo $remoteId;
            echo "\"/>\r\n<div style=\"width: auto; height: auto; overflow: hidden; margin-bottom: 10px; display: block;\"\r\nclass=\"form-group\">\r\n<img src=\"";
            echo $_obfuscated_0D2431403B3B1421180A385C3007152C13060F16133111_;
            echo "\"\r\nstyle=\"width:100%; margin-top: 10px; margin-bottom: 10px;\"/>\r\n<span style=\"padding:0px;\" class=\"col-md-4\">Resim</span>\r\n<input class=\"col-md-8 dizianput\" name=\"featured_image\" style=\"color:black;\"\r\ntype=\"text\"\r\nvalue=\"";
            echo $_obfuscated_0D2431403B3B1421180A385C3007152C13060F16133111_;
            echo "\"/>\r\n</div>\r\n<div style=\"width: auto; height: auto; overflow: hidden; margin-bottom: 10px; display: block;\"\r\nclass=\"form-group\">\r\n<span style=\"padding:0px;\" class=\"col-md-4\">Yayımlanma</span>\r\n<select name=\"post_status\" id=\"post_status\" class=\"form-contarol col-md-8\">\r\n<option value=\"publish\" selected=\"selected\">Yayımla</option>\r\n<option value=\"draft\">Taslak</option>\r\n</select>\r\n</div>\r\n<div style=\"width: auto; height: auto; overflow: hidden; margin-bottom: 10px; display: block;\"\r\nclass=\"form-group\">\r\n<span style=\"padding:0px;\" class=\"col-md-4\">Kategori</span>\r\n<span class=\"col-md-8\">\r\n<select multiple=\"\" class=\"multiple-control form-control\"\r\nstyle=\"width: 105%; height:200px;margin-left: -15px;border: 1px solid #DDDDDD;\"\r\nname=\"kategoriler[]\">\r\n";
            $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_ = "";
            $_obfuscated_0D062F2D04340B1A062B162B1C021C3C3B212609290101_ = get_categories(["hide_empty" => false]);
            $_obfuscated_0D241F1A10020F171032190323012D3B3105392F3D0501_ = "";
            
            
            
            foreach ($_obfuscated_0D062F2D04340B1A062B162B1C021C3C3B212609290101_ as $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_) {
                if (count($_GET["kategoriler"]) && in_array($_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->term_id, $_GET["kategoriler"])) {
                    print($_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->term_id);
                    $_obfuscated_0D241F1A10020F171032190323012D3B3105392F3D0501_ = "selected";
                }else {
                    $_obfuscated_0D241F1A10020F171032190323012D3B3105392F3D0501_ = "";
                }
                $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_ .= "<option value='" . $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->term_id . "' " . $_obfuscated_0D241F1A10020F171032190323012D3B3105392F3D0501_ . " >" . $_obfuscated_0D3F141F322A142B40120D1111044004133C2334162332_->cat_name . "</option>";
            }
            
            
            
            
            echo $_obfuscated_0D2F092F301E11252301161E21393E3D182B2D350F1A01_;
            echo "</select>\r\n</span>\r\n</div>\r\n</div>\r\n\r\n\r\n<div style=\"border-left: 1px solid #dedede;\" class=\"col-lg-8 beyazVer\">\r\n<div class=\"form-group\">\r\n<span class=\"col-md-12 paddingSil2\">BAŞLIK</span>\r\n<input class=\"dizinput col-md-12 input-sm \" name=\"post_title\" style=\"color:black;\"\r\ntype=\"text\" value=\"";
            echo $_obfuscated_0D30131519060A171E051F24341E3E32183F1C29235C11_;
            echo "\"/>\r\n</div>\r\n<div class=\"form-group\">\r\n<span class=\"col-md-12 paddingSil2\">ETİKETLER</span>\r\n<input class=\"dizinput col-md-12 input-lg\" name=\"tags\" style=\"color:black;\"\r\ntype=\"text\" value=\"";
            echo $_obfuscated_0D330B0D08131912011C2F023B3E370513190B06213C01_;
            echo "\"/>\r\n</div>\r\n<div class=\"form-group\">\r\n<span class=\"col-md-12 paddingSil2\">MANŞET SEÇİMİ</span>\r\n<span style=\"padding: 0px;\" class=\"col-md-12 checkler\">\r\n<div style=\"width: 100%;overflow: hidden;float:left;display:inline;margin-bottom: 15px;padding: 8px 0px 0px 5px;background: #DCDCDC;\">\r\n<input type=\"checkbox\" name=\"ozellikler_manset\"\r\nid=\"ozellikler_manset";
            echo $i;
            echo "\" type=\"checkbox\"/>\r\n<label for=\"ozellikler_manset";
            echo $i;
            echo "\">Manşet</label>\r\n<input type=\"checkbox\" name=\"ozellikler_mansetBuyuk\"\r\nid=\"ozellikler_mansetBuyuk";
            echo $i;
            echo "\" type=\"checkbox\"/>\r\n<label for=\"ozellikler_mansetBuyuk";
            echo $i;
            echo "\">Büyük Manşet</label>\r\n<input type=\"checkbox\" name=\"ozellikler_sondk\"\r\nid=\"ozellikler_sondk";
            echo $i;
            echo "\" type=\"checkbox\"/>\r\n<label for=\"ozellikler_sondk";
            echo $i;
            echo "\">Son Dakika</label>\r\n<input type=\"checkbox\" name=\"ozellikler_surmanset\"\r\nid=\"ozellikler_surmanset";
            echo $i;
            echo "\" type=\"checkbox\"/>\r\n<label for=\"ozellikler_surmanset";
            echo $i;
            echo "\">Sürmanşet</label>\r\n<input type=\"checkbox\" name=\"ozellikler_surmanset2\"\r\nid=\"ozellikler_surmanset2";
            echo $i;
            echo "\" type=\"checkbox\"/>\r\n<label for=\"ozellikler_surmanset2";
            echo $i;
            echo "\">Öne Çıkan</label>\r\n</div>\r\n</span>\r\n</div>\r\n<div class=\"form-group\">\r\n<span class=\"col-md-12 paddingSil2\">TARİH AYARLARI</span>\r\n<span style=\"padding: 0px;\" class=\"col-md-12\">\r\n<input type=\"hidden\" name=\"orjinyil\" value=\"";
            echo $_obfuscated_0D2D290A053E0D02252F2202210A0F0B100F3C39251E22_;
            echo "\"/>\r\n<select name=\"year\" id=\"year\" style=\"color:black\">\r\n<option selected=\"selected\" value=\"";
            echo $_obfuscated_0D2D290A053E0D02252F2202210A0F0B100F3C39251E22_;
            echo "\">";
            echo $_obfuscated_0D2D290A053E0D02252F2202210A0F0B100F3C39251E22_;
            echo "</option><option\r\nvalue=\"";
            echo date("Y") + 1;
            echo "\">";
            echo date("Y") + 1;
            echo "</option><option\r\nvalue=\"";
            echo date("Y") + 2;
            echo "\">";
            echo date("Y") + 2;
            echo "</option><option\r\nvalue=\"";
            echo date("Y") + 3;
            echo "\">";
            echo date("Y") + 3;
            echo "</option><option\r\nvalue=\"";
            echo date("Y") + 4;
            echo "\">";
            echo date("Y") + 4;
            echo "</option><option\r\nvalue=\"";
            echo date("Y") + 5;
            echo "\">";
            echo date("Y") + 5;
            echo "</option> <option\r\nvalue=\"";
            echo date("Y") + 6;
            echo "\">";
            echo date("Y") + 6;
            echo "</option>   <option\r\nvalue=\"";
            echo date("Y") + 7;
            echo "\">";
            echo date("Y") + 7;
            echo "</option>  <option\r\nvalue=\"";
            echo date("Y") + 8;
            echo "\">";
            echo date("Y") + 8;
            echo "</option>   <option\r\nvalue=\"";
            echo date("Y") + 9;
            echo "\">";
            echo date("Y") + 9;
            echo "</option>   <option\r\nvalue=\"";
            echo date("Y") + 10;
            echo "\">";
            echo date("Y") + 10;
            echo "</option>\r\n</select> /\r\n<input type=\"hidden\" name=\"orjinay\" value=\"";
            echo $_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_;
            echo "\"/>\r\n<select name=\"month\" id=\"month\" style=\"color:black\">\r\n<option value=\"01\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 1) {
                echo "selected";
            }
            echo ">Ocak</option>\r\n<option value=\"02\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 2) {
                echo "selected";
            }
            echo ">Subat</option>\r\n<option value=\"03\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 3) {
                echo "selected";
            }
            echo ">Mart</option>\r\n<option value=\"04\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 4) {
                echo "selected";
            }
            echo ">Nisan</option>\r\n<option value=\"05\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 5) {
                echo "selected";
            }
            echo ">Mayis</option>\r\n<option value=\"06\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 6) {
                echo "selected";
            }
            echo ">Haziran</option>\r\n<option value=\"07\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 7) {
                echo "selected";
            }
            echo ">Temmuz</option>\r\n<option value=\"08\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 8) {
                echo "selected";
            }
            echo ">Agustos</option>\r\n<option value=\"09\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 9) {
                echo "selected";
            }
            echo ">Eylül</option>\r\n<option value=\"10\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 10) {
                echo "selected";
            }
            echo ">Ekim</option>\r\n<option value=\"11\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 11) {
                echo "selected";
            }
            echo ">Kasim</option>\r\n<option value=\"12\" ";
            if ($_obfuscated_0D130D32292F0C2B0D18192F2A2E27231D0C170C390811_ == 12) {
                echo "selected";
            }
            echo ">Aralik</option>\r\n</select> /\r\n<input type=\"hidden\" name=\"orjingun\" value=\"";
            echo $_obfuscated_0D33110A371025283314251629401F1E0E2A2417120311_;
            echo "\"/>\r\n<select name=\"day\" id=\"day\" style=\"color:black\">\r\n<option selected=\"selected\" value=\"";
            echo $_obfuscated_0D33110A371025283314251629401F1E0E2A2417120311_;
            echo "\">";
            echo $_obfuscated_0D33110A371025283314251629401F1E0E2A2417120311_;
            echo "</option>\r\n";
            for ($_obfuscated_0D32111E0A0D3634052824210F0704160D1D2B34341901_ = 1; $_obfuscated_0D32111E0A0D3634052824210F0704160D1D2B34341901_ < 32; $_obfuscated_0D32111E0A0D3634052824210F0704160D1D2B34341901_++) {
                if (strlen($_obfuscated_0D32111E0A0D3634052824210F0704160D1D2B34341901_) == 1) {
                    $_obfuscated_0D13043D14183B14181F021306382D0E250B300A061522_ = "0" . $_obfuscated_0D32111E0A0D3634052824210F0704160D1D2B34341901_;
                } else {
                    $_obfuscated_0D13043D14183B14181F021306382D0E250B300A061522_ = $_obfuscated_0D32111E0A0D3634052824210F0704160D1D2B34341901_;
                }
                echo "<option value=\"" . $_obfuscated_0D13043D14183B14181F021306382D0E250B300A061522_ . "\">" . $_obfuscated_0D13043D14183B14181F021306382D0E250B300A061522_ . "</option>";
            }
            echo "</select>\r\n</span>\r\n</div>\r\n<div style=\"clear:both;\"></div>\r\n<div class=\"form-group\">\r\n<span class=\"col-md-12 paddingSil2\">HABERİN ÖZETİ ( SPOT )</span>\r\n<textarea name=\"post_excerpt\"\r\nstyle=\"height: 60px;width: 100%;\">";
            echo $_obfuscated_0D043829050F0E1D312E11091C03223B165C332A0A0822_;
            echo "</textarea>\r\n</div>\r\n<div style=\"clear:both;\"></div>\r\n<div class=\"form-group\">\r\n\r\n";
            $_obfuscated_0D191B113E3E3B26243D5B15402813211E2E27155B1C22_ = ["wpautop" => true, "media_buttons" => true, "textarea_name" => "post_content", "textarea_rows" => "10", "tabindex" => "", "editor_css" => "", "editor_class" => "", "teeny" => false, "dfw" => false, "tinymce" => true, "quicktags" => true];
            wp_editor($_obfuscated_0D323D1B125B37262709131B371025071A32150C120D22_, "editor_class", $_obfuscated_0D191B113E3E3B26243D5B15402813211E2E27155B1C22_);
            echo "</div>\r\n<div class=\"form-group\">\r\n\r\n";
            if ($_obfuscated_0D110412161615272D21280B0E06210D3C21120A1B5C01_) {
                foreach ($_obfuscated_0D110412161615272D21280B0E06210D3C21120A1B5C01_ as $key => $value) {
                    echo "<span class=\"col-md-12 paddingSil2\">Özel Alan (";
                    echo $key;
                    echo ")</span>\r\n<textarea name=\"custom_fields[";
                    echo $key;
                    echo "]\"\r\nstyle=\"height: 60px;width: 100%;\">";
                    echo $value;
                    echo "</textarea>\r\n";
                }
            }
            echo "\r\n</div>\r\n\r\n\r\n<div class=\"form-group\">\r\n<input style=\"float:right;\" type=\"Submit\" class=\"btn btn-danger\" value=\"HABERİ EKLE\"\r\nonclick=\"gizle(";
            echo $i;
            echo ");\">\r\n<br/>\r\n<br/>\r\n</div>\r\n</div>\r\n</form>\r\n</div>\r\n</div>\r\n</section>\r\n\r\n<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js\"></script>\r\n<script type=\"text/javascript\">\r\n\r\n\$(\".konugonder\").click(\r\nfunction () {\r\nvar sirano = \$(this).attr(\"sirano\");\r\n\$(\"#degis\" + sirano).html('<span class=\"fileupload-loading\"></span> Lütfen bekleyin... ');\r\n\r\n\$.ajax({\r\ntype: 'POST',\r\nurl: \"admin.php?page=";
            echo $_GET["page"];
            echo "&section=addPost\",\r\ndata: \$('#form' + sirano).serialize(),\r\nsuccess: function (data, status) {\r\nvar matches = data.match(/KonuSonucu\\[(.*)\\]\\[(\\d+)\\]/);\r\n\$(\"#degis\" + sirano).html(matches[1]);\r\n}\r\n})\r\n}\r\n)\r\n</script>\r\n\r\n";
        } else {
            echo "Bu haber daha önce eklenmiş.";
        }
    }
    public function addPost()
    {
        $_obfuscated_0D24042C12061B403B2B40230A1C0A2B3D1D10021F1922_ = "";
        $_obfuscated_0D3408141140340510383122331307380B13033E3D0101_ = $_POST["kategoriler"];
        $_obfuscated_0D30131519060A171E051F24341E3E32183F1C29235C11_ = $_POST["post_title"];
        $_obfuscated_0D340C295C321536260E3939223C141F28113D09172611_ = isset($_POST["post_status"]) ? $_POST["post_status"] : "publish";
        $_obfuscated_0D3C2D2E33362C04300F300E170D341F225C3D281B3532_ = $_POST["post_excerpt"];
        $_obfuscated_0D330B0D08131912011C2F023B3E370513190B06213C01_ = $_POST["tags"];
        $_obfuscated_0D323D1B125B37262709131B371025071A32150C120D22_ = htmlspecialchars_decode($_POST["post_content"], ENT_COMPAT);
        $_obfuscated_0D2431403B3B1421180A385C3007152C13060F16133111_ = $_POST["featured_image"];
        $remoteId = $_POST["remote_id"];
        $_obfuscated_0D3637060A3D05192F1325380804065C2A4003193D1822_ = sanitize_title($_obfuscated_0D30131519060A171E051F24341E3E32183F1C29235C11_);
        $_obfuscated_0D1804353012220E1E1F0F40320114401935340E300811_ = $_POST["orjindakika"];
        $_obfuscated_0D2D023F08293C073D230D082D063B1A360536061D3611_ = $_POST["orjinsaat"];
        $_obfuscated_0D0C22030609291C1A0A3D310D393C183C043334390A01_ = $_POST["orjingun"];
        $_obfuscated_0D1D102331031F5C5C0F292C3F3B3D353124363C243532_ = $_POST["orjinay"];
        $_obfuscated_0D18325C2E37141B2A073F1837103B2D2618321D2A1601_ = $_POST["orjinyil"];
        $_obfuscated_0D265C0A26043F07160C28252E06230F5B2239081D3B32_ = $_POST["year"];
        $_obfuscated_0D3610035B0E281A030D101C110F1632061103160B3D32_ = $_POST["month"];
        $_obfuscated_0D0416083926145B333B1A302E015C2F16012436011801_ = $_POST["day"];
        $_obfuscated_0D3C245C37381F04183D3E063006282E23031934262932_ = $_POST["hour"];
        $_obfuscated_0D232B160B1C1C3E304017060B1E08011E3B1A19123C11_ = $_POST["minute"];
        $_obfuscated_0D170635091A080C15020927133C242A3C250332384022_ = "" . $_obfuscated_0D265C0A26043F07160C28252E06230F5B2239081D3B32_ . "-" . $_obfuscated_0D3610035B0E281A030D101C110F1632061103160B3D32_ . "-" . $_obfuscated_0D0416083926145B333B1A302E015C2F16012436011801_ . " " . $_obfuscated_0D3C245C37381F04183D3E063006282E23031934262932_ . ":" . $_obfuscated_0D232B160B1C1C3E304017060B1E08011E3B1A19123C11_ . ":11";
        $_obfuscated_0D5C061F0333393807133E5B071B1402113C3E13211732_ = "" . $_obfuscated_0D18325C2E37141B2A073F1837103B2D2618321D2A1601_ . "-" . $_obfuscated_0D1D102331031F5C5C0F292C3F3B3D353124363C243532_ . "-" . $_obfuscated_0D0C22030609291C1A0A3D310D393C183C043334390A01_ . " " . $_obfuscated_0D2D023F08293C073D230D082D063B1A360536061D3611_ . ":" . $_obfuscated_0D1804353012220E1E1F0F40320114401935340E300811_ . ":11";
        if ($_obfuscated_0D265C0A26043F07160C28252E06230F5B2239081D3B32_ != $_obfuscated_0D18325C2E37141B2A073F1837103B2D2618321D2A1601_ || $_obfuscated_0D3610035B0E281A030D101C110F1632061103160B3D32_ != $_obfuscated_0D1D102331031F5C5C0F292C3F3B3D353124363C243532_ || $_obfuscated_0D0416083926145B333B1A302E015C2F16012436011801_ != $_obfuscated_0D0C22030609291C1A0A3D310D393C183C043334390A01_ || $_obfuscated_0D3C245C37381F04183D3E063006282E23031934262932_ != $_obfuscated_0D2D023F08293C073D230D082D063B1A360536061D3611_ || $_obfuscated_0D232B160B1C1C3E304017060B1E08011E3B1A19123C11_ != $_obfuscated_0D1804353012220E1E1F0F40320114401935340E300811_) {
            $_obfuscated_0D0809185B3C253D1518272D261C1C0A25343727325B22_ = "degisti";
        } else {
            $_obfuscated_0D0809185B3C253D1518272D261C1C0A25343727325B22_ = "";
        }
        if ($this->dataFinder->toBeAdd($remoteId)) {
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_ = [];
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_title"] = stripslashes($_obfuscated_0D30131519060A171E051F24341E3E32183F1C29235C11_);
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_content"] = htmlspecialchars_decode($_obfuscated_0D323D1B125B37262709131B371025071A32150C120D22_);
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_excerpt"] = htmlspecialchars_decode($_obfuscated_0D3C2D2E33362C04300F300E170D341F225C3D281B3532_);
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_status"] = $_obfuscated_0D340C295C321536260E3939223C141F28113D09172611_;
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_author"] = 1;
            if ($_obfuscated_0D0809185B3C253D1518272D261C1C0A25343727325B22_ == "degisti") {
                $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_status"] = "future";
                $_obfuscated_0D302A0C0836393F383333101E3B1617170F07021A3111_ = mktime($_obfuscated_0D3C245C37381F04183D3E063006282E23031934262932_, $_obfuscated_0D232B160B1C1C3E304017060B1E08011E3B1A19123C11_, 11, $_obfuscated_0D3610035B0E281A030D101C110F1632061103160B3D32_, $_obfuscated_0D0416083926145B333B1A302E015C2F16012436011801_, $_obfuscated_0D265C0A26043F07160C28252E06230F5B2239081D3B32_);
                $_obfuscated_0D0C0E23183F382F2E17072126282836320A3D1C323432_ = date("Y-m-d H:i:s", $_obfuscated_0D302A0C0836393F383333101E3B1617170F07021A3111_);
                $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_date"] = $_obfuscated_0D0C0E23183F382F2E17072126282836320A3D1C323432_;
                $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_date_gmt"] = $_obfuscated_0D0C0E23183F382F2E17072126282836320A3D1C323432_;
            }
            if ($_obfuscated_0D340C295C321536260E3939223C141F28113D09172611_ == "Taslak") {
                $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_status"] = "draft";
            }
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_category"] = $_obfuscated_0D3408141140340510383122331307380B13033E3D0101_;
            $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["tags_input"] = $_obfuscated_0D330B0D08131912011C2F023B3E370513190B06213C01_;
            $_obfuscated_0D2B1625113713230836302C24032C1232291D0D0B2711_ = wp_insert_post($_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_);
            add_post_meta($_obfuscated_0D2B1625113713230836302C24032C1232291D0D0B2711_, "remoteId", $remoteId);
            $_obfuscated_0D0F011A2D130E0B1A113E301D0324382B0B0E1C2A4022_ = "";
            if (isset($_POST["custom_fields"]["ozellikler_videOzet"])) {
                $_obfuscated_0D0F011A2D130E0B1A113E301D0324382B0B0E1C2A4022_ = $_POST["custom_fields"]["ozellikler_videOzet"];
            }
            $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_["ozellikler_manset"] = $_POST["ozellikler_manset"] == "on" ? "1" : "";
            $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_["ozellikler_mansetBuyuk"] = $_POST["ozellikler_mansetBuyuk"] == "on" ? "1" : "";
            $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_["ozellikler_yatayManset"] = $_POST["ozellikler_yatayManset"] == "on" ? "1" : "";
            $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_["ozellikler_sondk"] = $_POST["ozellikler_sondk"] == "on" ? "1" : "";
            $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_["ozellikler_surmanset"] = $_POST["ozellikler_surmanset"] == "on" ? "1" : "";
            $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_["ozellikler_surmanset2"] = $_POST["ozellikler_surmanset2"] == "on" ? "1" : "";
            $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_["ozellikler_videOzet"] = $_obfuscated_0D0F011A2D130E0B1A113E301D0324382B0B0E1C2A4022_;
            add_post_meta($_obfuscated_0D2B1625113713230836302C24032C1232291D0D0B2711_, "meta_manset_ayarlar", $_obfuscated_0D19042934155C1E33081538361D353D1C242904032232_);
            if (true) {
                $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_ = [];
                $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["post_content"] = myimages(stripslashes($_obfuscated_0D323D1B125B37262709131B371025071A32150C120D22_), $_obfuscated_0D3637060A3D05192F1325380804065C2A4003193D1822_);
                $_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_["ID"] = $_obfuscated_0D2B1625113713230836302C24032C1232291D0D0B2711_;
                wp_update_post($_obfuscated_0D01350B0E12085C1D2D05070B3B0334063B0F3C082A22_);
            }
            if ($_obfuscated_0D2B1625113713230836302C24032C1232291D0D0B2711_) {
                $_obfuscated_0D24042C12061B403B2B40230A1C0A2B3D1D10021F1922_ .= "Haber başarıyla eklenmiştir.";
            }
            include_once ABSPATH . "wp-includes/formatting.php";
            require_once ABSPATH . "wp-admin/includes/image.php";
            $_obfuscated_0D33321B3B2E2A270F392B400B13141D120F312A3B0C32_ = filedownload($_obfuscated_0D2431403B3B1421180A385C3007152C13060F16133111_, $_obfuscated_0D3637060A3D05192F1325380804065C2A4003193D1822_ . "-" . md5(uniqid("img", true)));
            $_obfuscated_0D1610311A083E232D2D2D3B1D01142131175C233F0F01_ = $_obfuscated_0D33321B3B2E2A270F392B400B13141D120F312A3B0C32_["path"];
            $_obfuscated_0D26123B090D163D3823162D0D22362C133C2B04221732_ = wp_check_filetype(basename($_obfuscated_0D1610311A083E232D2D2D3B1D01142131175C233F0F01_), NULL);
            $_obfuscated_0D3B1F1E082A3C370A3610132C0A012E2E1B0E28161622_ = ["post_mime_type" => $_obfuscated_0D26123B090D163D3823162D0D22362C133C2B04221732_["type"], "post_title" => $_obfuscated_0D30131519060A171E051F24341E3E32183F1C29235C11_, "post_content" => "", "post_status" => "inherit"];
            $_obfuscated_0D052D0B1D3D2F232A372E283B17141A14081E17010B22_ = wp_insert_attachment($_obfuscated_0D3B1F1E082A3C370A3610132C0A012E2E1B0E28161622_, $_obfuscated_0D1610311A083E232D2D2D3B1D01142131175C233F0F01_, $_obfuscated_0D2B1625113713230836302C24032C1232291D0D0B2711_);
            $_obfuscated_0D1C2D40330D113137333C32101F3821282B3E382E2522_ = wp_generate_attachment_metadata($_obfuscated_0D052D0B1D3D2F232A372E283B17141A14081E17010B22_, $_obfuscated_0D1610311A083E232D2D2D3B1D01142131175C233F0F01_);
            wp_update_attachment_metadata($_obfuscated_0D052D0B1D3D2F232A372E283B17141A14081E17010B22_, $_obfuscated_0D1C2D40330D113137333C32101F3821282B3E382E2522_);
            set_post_thumbnail($_obfuscated_0D2B1625113713230836302C24032C1232291D0D0B2711_, $_obfuscated_0D052D0B1D3D2F232A372E283B17141A14081E17010B22_);
        } else {
            $_obfuscated_0D24042C12061B403B2B40230A1C0A2B3D1D10021F1922_ .= "Daha önce eklenmiştir.";
        }
        echo "<!--KonuSonucu[" . $_obfuscated_0D24042C12061B403B2B40230A1C0A2B3D1D10021F1922_ . "][15]-->";
        echo $_obfuscated_0D24042C12061B403B2B40230A1C0A2B3D1D10021F1922_;
    }
}
function myImages($post_content, $sefLink)
{
    preg_match_all("/<img[^']*?src=\"([^']*?)\"[^']*?>/", $post_content, $_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_);
    if (!$_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_[1]) {
        preg_match_all("|<img.*?src='(.*?)'.*?>|", $post_content, $_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_);
    }
    if (count($_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_[1]) != 0) {
        for ($i = 0; $i < count($_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_[1]); $i++) {
            $_obfuscated_0D181D311D05081B1E04342F1A17171C232A0115033C01_ = $_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_[0][$i];
            $_obfuscated_0D5C1204290A24393E2E313B312807090C0D0628101222_ = $_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_[1][$i];
            $_obfuscated_0D1F0C071B5B1A2226241B3E15161417402F40281C1F11_ = fileDownload($_obfuscated_0D5C1204290A24393E2E313B312807090C0D0628101222_, $sefLink . "-" . $i);
            $_obfuscated_0D291E16092829291A042D035C0140400C102F2D340922_ = $_obfuscated_0D1F0C071B5B1A2226241B3E15161417402F40281C1F11_["url"];
            if (strstr($post_content, "nextpage")) {
                $_obfuscated_0D31392D2B0206232E163C09120E1E1F30053222323322_ = "<a href=\"" . $_obfuscated_0D291E16092829291A042D035C0140400C102F2D340922_ . "\"><img src=\"" . $_obfuscated_0D291E16092829291A042D035C0140400C102F2D340922_ . "\" /></a>";
                if ($i + 1 == count($_obfuscated_0D070B151B34403C06071205020A5C093D062D225B0E22_)) {
                    $_obfuscated_0D31392D2B0206232E163C09120E1E1F30053222323322_ = "<a href=\"/populer-galeriler\"><img src=\"" . $_obfuscated_0D291E16092829291A042D035C0140400C102F2D340922_ . "\" /></a>";
                }
            } else {
                $_obfuscated_0D31392D2B0206232E163C09120E1E1F30053222323322_ = "<img src=\"" . $_obfuscated_0D291E16092829291A042D035C0140400C102F2D340922_ . "\" />";
            }
            $post_content = str_replace($_obfuscated_0D181D311D05081B1E04342F1A17171C232A0115033C01_, $_obfuscated_0D31392D2B0206232E163C09120E1E1F30053222323322_, $post_content);
        }
    }
    return $post_content;
}
function connect($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIESESSION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, "theWp Bot");
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 200);
    curl_setopt($ch, CURLOPT_URL, $url);
    $result = curl_exec($ch);
    return $result;
}
function fileDownload($link, $disim)
{
    $_obfuscated_0D2533210C311D38290E1A2928082E4039233B14083C22_ = wp_upload_dir();
    $_obfuscated_0D09105C123F4034292D033C272505041917101F010322_ = $_obfuscated_0D2533210C311D38290E1A2928082E4039233B14083C22_["path"];
    $_obfuscated_0D301C100B2340232D09042D111B2F37333C2D2B0A0C01_ = pathinfo($link);
    $_obfuscated_0D3F1A322A14110613063C0E211B03110C3D053F150D11_ = strtolower($_obfuscated_0D301C100B2340232D09042D111B2F37333C2D2B0A0C01_["extension"]);
    $file = $disim . "." . $_obfuscated_0D3F1A322A14110613063C0E211B03110C3D053F150D11_;
    $file = str_replace([" ", "%20"], "_", $file);
    $_obfuscated_0D1F3C08010D3D1F3C3E0E362B1E2F3F3C2D3D301F0632_ = curl_init($link);
    $fopen = fopen($_obfuscated_0D09105C123F4034292D033C272505041917101F010322_ . "/" . $file, "w");
    $data = connect($link);
    fwrite($fopen, $data);
    fclose($fopen);
    $_obfuscated_0D26123F271B1839020A2929313C2A2A120F3D155C2301_["url"] = $_obfuscated_0D2533210C311D38290E1A2928082E4039233B14083C22_["url"] . "/" . $file;
    $_obfuscated_0D26123F271B1839020A2929313C2A2A120F3D155C2301_["path"] = $_obfuscated_0D2533210C311D38290E1A2928082E4039233B14083C22_["path"] . "/" . $file;
    return $_obfuscated_0D26123F271B1839020A2929313C2A2A120F3D155C2301_;
}

?>