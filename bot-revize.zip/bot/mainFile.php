<link rel="stylesheet" href="<?php echo plugin_dir_url( __FILE__ )?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url( __FILE__ )?>css/styles.css">
<?php
$views = new TheWpMainViews();
$section = isset($_GET['section']) ? $_GET['section'] : null;
switch ($section) {
    case 'listing':
        $views->listingView();
        break;
    case 'advancedEditor':
        $views->advancedEditorView();
        break;
    case 'addPost':
        $views->addPost();
        break;
    default:
        $views->mainView();
}
?>