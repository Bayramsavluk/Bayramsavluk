<?php
/*
Plugin Name: Haber Botu V8
Plugin URI: https://www.google.com.tr/webhp?hl=tr&sa=X&ved=0ahUKEwjpz9WD3_3PAhXFAsAKHVN7AqcQPAgD
Description: Haber Siteleri İçin İçerik Çekmek Amacıyla Hazırlanmıştır.
Author: botv8.COM.TR
Version: 1.0
Author URI: http://www.thebotv8.com.tr
*/

define('THEWP_PLUGIN_FNAME', basename(__FILE__));
$appName = "theWpHaberBot";

include "TheWpMainV6.php";

function menuAdd()
{
    add_menu_page('Haber Botları V8', 'Haber Havuzu V8', 'manage_options', 'haberHavuzu');
    add_submenu_page('haberHavuzu', 'Tüm Botlar', 'Tüm Botlar', 'manage_options', 'haberHavuzu', 'main_page');
    add_submenu_page('haberHavuzu','Yerel Haber Botları', 'Yerel Haber Botları', 'manage_options', 'yerelHaberler', 'main_page');

}
add_action('admin_menu', 'menuAdd');

function main_page()
{
    include("mainFile.php");
}
?>
